package com.akolekar.Hibernate;

/**
 * Hello world!
 *
 */
/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.Transaction;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

public class App {
	
//	public static void main (String args[]){
//		System.out.println( "Hello World");
//		try{
//			Student Abhi = new Student();
//			Abhi.setRollno(4);
//			Abhi.setName("Abhijit K");
//			Abhi.setHouse("Red");
//			Abhi.setValid(1);
//			Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class);
//			ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
//			SessionFactory Sf = Con.buildSessionFactory(reg);
//			Session session = Sf.openSession();
//			Transaction tx = session.beginTransaction();
//			session.save(Abhi);
//			tx.commit();
//			
//		} catch(Exception e){
//			System.out.println("Error");
//			e.printStackTrace();
//			
//		}
//		
//	}
	
	
	//Fetching Values from Database
//	public static void main (String args[]){
//		System.out.println( "Hello World");
//		Student Abhi = null;
//		Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class);
//		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
//		SessionFactory Sf = Con.buildSessionFactory(reg);
//		Session session = Sf.openSession();
//		Transaction tx = session.beginTransaction();
//		Abhi = (Student)session.get(Student.class,3);
//		tx.commit();
//		System.out.println("Name : "+Abhi.getName()+" Roll No : "+Abhi.getRollno()+" House : "+Abhi.getHouse()+ " Valid : "+Abhi.getValid());			
//	}
	
	//Embedabble= One Table but Two Class
	//One to One ==> One Person Can have One Aaddhar
	//One to Many ==>One User can have Many Accounts but One Account is per user
	//Many to Many ==>One Customer can Many Product and One Product can purchased by Many Customer
	public static void main (String args[]){
		System.out.println( "Hello World");
		try{
			
			
			StudentName StudName = new StudentName();
			StudName.setStudentId(101);
			StudName.setFname("Niki");
			StudName.setLname("Dgaar");
			StudName.setMame("Sarur");
			
			Student Stud = new Student();
			Stud.setRollno(1);
			Stud.setHouse("Diamond");
			Stud.setValid(1);
			
			Course StudCourse = new Course();
			StudCourse.setCourseID(1002);
			StudCourse.setCourseName("English");
			
			Course StudCourse1 = new Course();
			StudCourse1.setCourseID(1001);
			StudCourse1.setCourseName("Maths");
			
			
			Stud.getStudentname().add(StudName);
			StudName.setStudent(Stud);
			
			Stud.getCoursename().add(StudCourse);
			Stud.getCoursename().add(StudCourse1);
			StudCourse.getStudent1().add(Stud);
			StudCourse1.getStudent1().add(Stud);
			
			Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class).addAnnotatedClass(StudentName.class).addAnnotatedClass(Course.class);
			ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
			SessionFactory Sf = Con.buildSessionFactory(reg);
			Session session = Sf.openSession();
			Transaction tx = session.beginTransaction();
			session.save(StudName);
			session.save(Stud);
			session.save(StudCourse);
			session.save(StudCourse1);
			tx.commit();
			
		} catch(Exception e){
			System.out.println("Error");
			
			e.printStackTrace();
			
		}
//		
	}
	//Caching 
	//Level 1 Caching is bydefault but if we differrent s
	//Level 2 Caching we need to add two external library 1 for Cache and another hibernate-cache where 2nd should match version of hibernate
//	public static void main (String args[]){
//	System.out.println( "Hello World");
//	try{
//		Student Abhi = null;
//		Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class);
//		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
//		SessionFactory Sf = Con.buildSessionFactory(reg);
//		Session session = Sf.openSession();
//		session.beginTransaction();
//		Abhi = (Student)session.get(Student.class, 1);
//		System.out.println(Abhi);
//		session.getTransaction().commit();
//		session.close();
//		
//		Session session1 = Sf.openSession();
//		session1.beginTransaction();
//		Abhi = (Student)session.get(Student.class, 1);
//		System.out.println(Abhi);
//		session1.getTransaction().commit();
//		session1.close();
//
//	} catch(Exception e){
//		System.out.println("Error");
//		e.printStackTrace();
//	} 
//}


	//Annotation
//	public static void main(String args[]) {
//		
//	}
	
	//HQL Querries
//	public static void main(String args[]) {
//		try{
//			Student Abhi = new Student();
//			Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class);
//			ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
//			SessionFactory Sf = Con.buildSessionFactory(reg);
//			Session session = Sf.openSession();
//			Transaction tx = session.beginTransaction();
//			Random r= new Random();
//			for(int i=0; i<50; i++) {
//				Student Abhi = new Student();
//				Abhi.setName("Abhi"+i);
//				Abhi.setHouse("Blue");
//				Abhi.setValid(1);
//				Abhi.setRollno(i);
//				session.save(Abhi);
//			}
//			Query Q = null;
			
			//Select * Query
//			Q = session.createQuery("from Student");
//			List<Student> students = Q.list();
//			for(Student student : students) {
//				System.out.println(student);
//			}
			
			
			//Where
//			Q = session.createQuery("from Student where rollno = 5");
//			Student student = (Student)Q.uniqueResult();
//			System.out.println(student);
			
			//Object use for getting different type of data
			//Q = session.createQuery("select rollno, Valid, name, house from Student");
//			List<Object[]> students = (List<Object[]>)Q.list();
//			for (Object[] student :students) {
//				System.out.println(student[0] + ":"+ student[1] +":"+ student[2] +":"+ student[3]);	
//			}
			//Anove and below we are doing string Concatennation
//			Q = session.createQuery("select sum(rollno) from Student");
//			long summarks = (long)Q.uniqueResult();
//			System.out.println(summarks);
			
			//Prepared Statment like JDBC
//			int roll =5;
//			//Where
//			Q = session.createQuery("from Student where rollno = :b");
//			Q.setParameter("b", roll);
//			Student student = (Student)Q.uniqueResult();
//			System.out.println(student);
			
			//Native Query or SQL Query
			//1 addEntity
//			SQLQuery Q1 = session.createSQLQuery("select * from Student");
//			Q1.addEntity(Student.class);
//			List<Student> students = Q1.list();
//			for (Student student : students) {
//				System.out.println(student);
//			}
			
			//2 
//			SQLQuery Q2 = session.createSQLQuery("select name, house from Student");
//			Q2.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
//			List data = Q2.list();
//			for(Object o : data) {
//				Map m= (Map)o;
//				System.out.println(m.get("name")+" "+ m.get("house"));
//			}
//			tx.commit();
//	
//		} catch(Exception e){
//			System.out.println("Error");
//			e.printStackTrace();
//		} 
//	}
//	
//	public static void main(String args[]) {
//		Configuration Con = new Configuration().configure().addAnnotatedClass(Student.class);
//		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(Con.getProperties()).buildServiceRegistry();
//		SessionFactory Sf = Con.buildSessionFactory(reg);
//		Session session = Sf.openSession();
//		try{
//			Transaction tx = session.beginTransaction();
//			
////			Student Abhi = (Student)session.get(Student.class, 1);
////			System.out.println(Abhi);
////			Abhi.setName("Amol");
////			session.update(Abhi);
//			
//			Student Anhi = new Student();
//			Anhi.setHouse("Red");
//			Anhi.setName("ADA");
//			Anhi.setRollno(50);
//			Anhi.setValid(2);
//			session.persist(Anhi);
//			
//			tx.commit();
//			session.close();
//	
//		} catch(Exception e){
//			System.out.println("Error");
//			e.printStackTrace();
//		}finally {
//			session.close();
//		}
//		System.exit(0);
//	}
	
//	public static void main(String args[]) {
//		
//		System.out.println("Hello World");
//		BuildConnection Conn = new BuildConnection();
//		Conn.AddAnnotatedClass(Student.class);
//		Session session = Conn.GetSession();
//		try {
//			session.beginTransaction();
//			Student Abhi = (Student)session.get(Student.class, 1);
//			System.out.println(Abhi);
//			session.getTransaction().commit();
//			session.close();
//			
//			Conn.AddAnnotatedClass(StudentName.class);
//			Session session1 = Conn.GetSession();
//			session.beginTransaction();
//			StudentName Abhi1 = new StudentName();
//			Abhi1.setFname("Abhi");
//			Abhi1.setLname("Kole");
//			Abhi1.setMame("Sure");
//			Abhi1.setStudentId(1);
//			System.out.println(Abhi);
//			session1.getTransaction().commit();
//			session1.close();
//			
//		}catch(Exception E) {
//			System.out.println("Error");
//			E.printStackTrace();
//		}
//		
//
//		
//		
//	}
}
