
package com.akolekar.Hibernate;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class StudentName {
	@Id
	private int studentId;
	private String fname;
	private String lname;
	private String mame;
	@ManyToOne
	private Student student;
	public String getFname() {
		return fname;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getMame() {
		return mame;
	}
	public void setMame(String mame) {
		this.mame = mame;
	}
	@Override
	public String toString() {
		return "StudentName [fname=" + fname + ", lname=" + lname + ", mame=" + mame + "]";
	}
	
}
