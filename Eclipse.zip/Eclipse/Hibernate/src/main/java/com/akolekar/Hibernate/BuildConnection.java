package com.akolekar.Hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class BuildConnection {
	private Configuration Conf;
	private JdbcConnection Con;
	private SessionFactory sF;
	public BuildConnection(){
		Con = new JdbcConnection();
		Conf = Con.SetConfiguration();
	}
	public void AddAnnotatedClass(Class Classname) {
		Conf.addAnnotatedClass(Classname);
		sF = Con.CreateSessionFactory(Conf, Con.BuildServiceRegistry(Conf));
	}
	public Session GetSession() {
		return Con.OpenSession(sF);
	}

}
