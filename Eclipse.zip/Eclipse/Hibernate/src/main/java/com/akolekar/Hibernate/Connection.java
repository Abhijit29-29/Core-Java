package com.akolekar.Hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public interface Connection{
	public Configuration SetConfiguration();
	public ServiceRegistry BuildServiceRegistry(Configuration Conf);
	
	public SessionFactory CreateSessionFactory(Configuration Conf, ServiceRegistry reg);
	
	public Session OpenSession(SessionFactory Sf);

}
