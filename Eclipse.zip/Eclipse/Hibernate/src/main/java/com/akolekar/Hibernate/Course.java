package com.akolekar.Hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Course {
	
	@Id
	private int CourseID;
	private String CourseName;
	
	@ManyToMany
	private List<Student> student1 = new ArrayList<Student>();
	public List<Student> getStudent1() {
		return student1;
	}
	public void setStudent1(List<Student> student1) {
		this.student1 = student1;
	}

	@Override
	public String toString() {
		return "Course [CourseID=" + CourseID + ", CourseName=" + CourseName + ", student1=" + student1 + "]";
	}
	public int getCourseID() {
		return CourseID;
	}
	public void setCourseID(int courseID) {
		CourseID = courseID;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	

}
