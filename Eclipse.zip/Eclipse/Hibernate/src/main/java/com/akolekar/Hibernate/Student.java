package com.akolekar.Hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;



@Entity
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class Student {
	
	@Id
	private int rollno;
	@OneToMany(mappedBy = "student")
	private List<StudentName> Studentname = new ArrayList<StudentName>();
	public List<StudentName> getStudentname() {
		return Studentname;
	}
	public void setStudentname(List<StudentName> studentname) {
		Studentname = studentname;
	}
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@ManyToMany(mappedBy = "student1")
	private List<Course> Coursename = new ArrayList<Course>();
	public List<Course> getCoursename() {
		return Coursename;
	}
	public void setCoursename(List<Course> courseStudentname) {
		Coursename = courseStudentname;
	}
	private String house;
	private int Valid;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public int getValid() {
		return Valid;
	}
	public void setValid(int Valid) {
		this.Valid = Valid;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", house=" + house + ", Valid=" + Valid + "]";
	}
}
