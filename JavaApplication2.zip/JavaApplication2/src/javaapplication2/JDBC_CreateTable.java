/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.sql.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Kolekar
 */
public class JDBC_CreateTable {
    public static void main (String args[]){
     try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        String username="root";
        String Pass= "1234";
        String Url = "jdbc:mysql://localhost:3306/jdbc";
        Connection Con = DriverManager.getConnection(Url,username,Pass);    
        if (Con.isClosed()){
            System.out.println("Not Connected");
        }
        else
            System.out.println("Connected");
            //BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            //System.out.println("Enter ID");
//            int ID = br.
            //String CreateQry = "create table JDBC(Tid int(20) primary key auto_increment, tName varchar(50), tCity varchar(50))";      
            String InsertQry= "insert into jdbc(tName,tCity) values (?,?)";
            PreparedStatement stmt=Con.prepareStatement(InsertQry);
            stmt.setString(1, "Abhijit K");
            stmt.setString(2, "US");
            String Qry= "insert into jdbc(tName,tCity) values ('Abhi','Mumbai')";
            stmt.executeUpdate();
            String SelectQry = "select * from jdbc";
//            Statement stmt1 = Con.createStatement();
            ResultSet set = stmt.executeQuery(SelectQry);

            System.out.println("Executed");
            while(set.next()){
                System.out.println(set.getInt("Tid"));
                System.out.println(set.getString("tName"));
                System.out.println(set.getString(3));
//                
            }
            Con.close();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
