/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;
import java.sql.*;
/**
 *
 * @author Kolekar
 */
public class JDBCConnection {
    public static void main(String args[]){
        
        
        try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        String username="root";
        String Pass = "1234";
        String Url = "jdbc:mysql://localhost:3306/jdbc";
        Connection Con = DriverManager.getConnection(Url,username,Pass);    
        if (Con.isClosed()){
            System.out.println("Not Connected");
        }
        else
            System.out.println("Connected");
            Con.close();
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
    
}
