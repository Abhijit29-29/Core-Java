//https://www.javatpoint.com/instantiation-in-java
//Java is purely A9_Object Oriented
//Building is object and Blueprint is the class 
//In Blueprint we can defined what object knows and what can do
//An object instantiation in Java provides the blueprint for the class.


/*
Initialization: Assigning a value to a variable is called initialization. For example, cost = 100. It sets the initial value of the variable cost to 100.

Instantiation: Creating an object by using the new keyword is called instantiation. For example, Car ca = new Car(). It creates an instance of the Car class.
*/
package javaapplication2;

public class A9_Object 
{
  
    public static void main(String[] args) 
    {
        //To create the object of class A
        //You create object in Heap Memory
        
        A obj1=new A();
/*        Here A is Class Name 
          Obj1 is Refrence Variable
          new is keyword            #Instanstiation a object using New Keyword  //new will provide the memory to every object in  Heap Memory with the help of Constructor
          A () is constructor
       
 */     
        //object in Heap Memory is Instance
        //As Refrenece Variables are in Stack which is linked to object which is in Heap Memory through hash code 
        obj1.display();     // We intialized same Obj1 two times
        System.out.println("");
        obj1=new A();     //Every time we use new the new object is created but as the refrence is same in both cases the old Link will Break
                            //Has Code will get changed as the new obj is created and this refrence will now have hash code of new obj 
     //Old A9_Object is ready for Garbage Collection as
        A obj=new A();
        obj.display();
        System.out.println("");
        
        
        //To Destroy the object
        obj=null;
        obj.display();     //It will give error
     //Now it is also ready for Garbage Collextion
     
     
     
        new A().display();         //This is Anonymous A9_Object, as it doesont have the refrence variable
                                   //It will not have any memory in stack
                                   //It will just created in Heap
                                   //Once the task is over it will be avaliable for Garbage Collection 
     
        
    }
    
}

//Object Creation

class A
{

    public void display()     //This is Method
    {
        System.out.println("Hello Method");
    }
    
}