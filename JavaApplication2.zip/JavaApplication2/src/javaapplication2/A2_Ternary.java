//It's a one-liner replacement for if-then-else statement 
package javaapplication2;

public class A2_Ternary {

    public static void main(String[] args) 
    {
       int i=7 ;
       int j;
       
//       A2_Ternary Operator
//       []=[Condition]?[True]:[False];
         j=i==7?8:5;
         System.out.println(j);
                 
    }
    
}
