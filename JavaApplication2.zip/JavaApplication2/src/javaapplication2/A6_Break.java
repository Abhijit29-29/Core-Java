 //To break the outer Loop Name the Outer Loop And add it ahead a break
package javaapplication2;

public class A6_Break {

    public static void main(String[] args) 
    {   
        Abhiji:       //Name the Outter Loop
        for(int i=0;i<=7;i++)
        {
            for(int j=0;j<=i;j++)
            {
                if (j==4)
                    break;                  //This break the inner For Loop
                if(i==5)
                    break Abhiji;          //This break the Outer For Loop               {Labelled Break Statemet}
               
                System.out.print("* ");

            }
         
            System.out.println(" ");
        }
    }
    
}
