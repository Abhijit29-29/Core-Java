/*
        Encapsulation
        To get and set values to variables in class we should use the Method.This is called the Encapsulation
        It help to hide the data from user
        Keep Your Variable Private
        If you keep variable Private u can set the value to that variable using the class obj

 */
package javaapplication2;


public class B6_Encapsulation {

    
    public static void main(String[] args) 
    {
 ///////////////////////////////////////////////////////////////////////////////
                //Getters and Setters for private Variables
        
       en obj=new en();
       //obj.i=10;  // You cant assign value as it is Private Variable
       obj.setI(10,"Abhijit");
       obj.setN("Abhijit");
       System.out.println(obj.getI());
       System.out.println(obj.getN());
       
 ///////////////////////////////////////////////////////////////////////////////
       //obj.MethodEncap();        //Giving Error  
      
     
       obj.call();
       
                    
    }
    
}


class en
{
 ///////////////////////////////////////////////////////////////////////////////
                        //Variable Encapsulation
    
    private int i;       //You cant access it outside the class
    private String N;
    public void setI(int i,String N)
    {
        this.i = i;    
        this.N=N;
   
    }   

    public int getI() 
    {
        return (i);
  
    }

    public void setN(String N)
    {
        this.N = N;
    }

    public String getN() 
    {
        return N;
    }
    
///////////////////////////////////////////////////////////////////////////////
                        //Method Encapsulation
    
    private void MethodEncap(){
        System.out.println("Method Encapsulation");          //Can't call the method with outisde class
    }
    
    public void call(){                             //Call this method which will call the private method of this class
        this.MethodEncap();
    }
    
}    

    
