/*https://www.javatpoint.com/java-constructor#consothertask
Java Copy Constructor
There is no copy constructor in Java. However, we can copy the values from one object to another like copy constructor in C++.

There are many ways to copy the values of one object into another in Java. They are:

By constructor
By assigning the values of one object into another
By clone() method of Object class
*/
package javaapplication2;


public class B1_CopyConstructor {

   
    public static void main(String[] args) {
        A obj1=new A();
        //A obj2=new A(obj1);
        
    }
    
}

class A{
    int i;int k;    //Only Instance variable can be copied
    public A( ){
        i=10;
        k=15;
        int l=34;
        System.out.println(i+" "+k);
    }
    public A(A ref){
        int a=ref.i;
        int b=ref.k;
        //int c=ref.l;     //Error

        System.out.println(a+" "+b);

    }
}

//we can copy data in another way also refer link.
/*
//Static Constructor
https://www.javatpoint.com/java-static-constructor
A static constructor used to initialize static data means the specified task will execute only once throughout the program. 
Usually, a static constructor is automatically called when the first instance is generated, or any static member is referenced. 
The static constructor is explicitly declared by using a static keyword. However, the static constructor is not allowed in Java.
*/