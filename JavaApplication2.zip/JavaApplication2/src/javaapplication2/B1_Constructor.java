
package javaapplication2;

/*
https://www.javatpoint.com/java-constructor

Name of the Constructor is same as the name of class
Constructor is member method
Every  class has defualt Constructor
Constructor wont return anything so no return Type is required
It is used to allocate the memory to object in Heap
It is used to assign value to instance Variable

In java Constructor allows only access modifiers
*/
public class B1_Constructor
{

   
    public static void main(String[] args)
    {
        
     
            /*
                Public-Everyone can access
                Static-As this is the main method u can called it without obj you cannot create obj without main so use 
                void-Does not return anything
                main-
            */
            Ac obj = new Ac();  //This will call the Defualt Constructor if we dont pass any parameter
            //new will provide the memory to every object in  Heap Memory with the help of Constructor

            Ac obj2=new Ac("Abhijit");
            Ac obj1=new Ac(4);
            
            //Factory Method as it static no need of class obj
            Ac obj3=Ac.getClassObj();
            
            //For Method with same name as parent class
            Bc ac=new Bc();
            ac.Ac();
            
           
                                   
              
    }
    
}
//Constructor Overloadig means constructor having same  name but having diiferent parameter list and Method
class Ac
{
    //we can have as many as constructor but should have different Parameter 
    Ac(){
        System.out.println("This Is Defualt Constructor");
        
    }
    private Ac(int a,int d){
        System.out.println("This Private Constructor ");  //When object is created within same class  and two 2 integer are passed Refer next 
    }
    
    protected  Ac(String S)
    {
        System.out.println("Access within package not outside package");  //When object created within same package and 1 String is passed
    }
    
    static int i;
    public Ac(int k)  //When object created anywhere and integer is passed
    {
        System.out.println("This is are paramatarized  Constructor & Constructor Overloading");
   
    }
  /*
    // As it is not possible to create the obj of Private Constructor from other we can create it by Static Factor Method
    //Now what is factory Method
    //It is method which is capabale of constructing  an returning the obj of class
    //There are two types of factory Methdod
    1:-Static Factory Method
    2:-Non Static Factory Method
    
    
    
 */
    public static Ac getClassObj(){        //this is public tatic factory method
        
        return new Ac(4,4);
    }
    
}
class Bc extends Ac{
    public  void Ac(){
            System.out.println("Method with same name as Parent class");
}
 
    
}
