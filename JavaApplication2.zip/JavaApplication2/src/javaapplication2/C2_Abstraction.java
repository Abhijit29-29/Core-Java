


/*      Abstraction
        Data abstraction is the process of hiding certain details and showing only essential information to the user.

        Abstraction can be achieved with either abstract classes or interfaces (which you will learn more about in the next chapter).

        The abstract keyword is a non-access modifier, used for classes and methods:

        Abstract class:-- is a restricted class that cannot be used to create objects (to access it, it must be inherited from another class).

        Abstract method:-- can only be used in an abstract class, and it does not have a body. The body is provided by the subclass (inherited from).
        
 */

//       An abstract class can have both abstract and regular methods  

//       Abstract methods are declared not Defineed----Defined in child Class

//       To access the abstract class, it must be inherited from another class
package javaapplication2;


public class C2_Abstraction 
{

    public static void main(String[] args) 
    {
        Mahesh obj=new Mahesh();    //Cannot instanciate the obj of abstract class
        obj.call();
        obj.msg();
        obj.cam();
        obj.play();
                
    }
    
}

abstract class Suresh
{
    public void call()
    {
        System.out.println("I only know this method-Suresh ");
                
    }
    public abstract void msg();
    public abstract void cam();
    public abstract void play(); 
    
}

abstract class Ramesh extends Suresh       
{
    public void msg()
    {
        System.out.println("I know this Ramesh");
    }
    public void cam()
    {
        System.out.println("I know about cam Also");
                
    }
//    public abstract void play();
    
}
class Mahesh extends Ramesh      //Concrete Class
{
    public void play()
    {
        System.out.println("I completed the design");
    }
    
    
}