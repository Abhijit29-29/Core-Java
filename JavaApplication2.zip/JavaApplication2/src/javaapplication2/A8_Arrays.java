
package javaapplication2;
//Arrays are conatainer which carries multiple elements of same type(Every elements should be of same type like int float....)
//Dimensional Arrays-Arrays carrying multiple arrays of same size 
//Jagged Array-Arrays Carrying multiple arrays of  different sizes 
import java.util.Random;
import java.util.*;

public class A8_Arrays {

    public static void main(String[] args) {
        int i[]=new int[2];              //data type name[]=new datatype[size]   need to create obj
        i[1]=8;
        i[0]=3;
        System.out.println(i);           //This will not give us array but hash code
        System.out.println(i[1]);
        System.out.println(Arrays.toString(i));         //This will print the array
        
        
        System.out.println("Enhanced For Loop"); 
        int values[]={1,2,3,4,5};
        System.out.println(Arrays.toString(values));      
        //Using Enhanced For Loop to print values
        for(int j:values){
        System.out.println(j);     
        }
        int l=values.length;
        System.out.println("l");
        
        //Using Random Values
        
        Random r=new Random();
        int a[]=new int[11];
        for(int k=0;k<11;k++){
            a[k]=r.nextInt(50);
        }
        
        for(int k1:a){
            System.out.println(k1);
       
        }
        
        
    }
    
}
