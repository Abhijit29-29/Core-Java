
package javaapplication2;


public class C5_Interface_Defualt_Static {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        sd o =new sd();
        if(o instanceof sd)
        {
            o.show();
        }
        ia.d();
    }
    
}

interface ia
{
    static   void d()
    {
        System.out.println("i am defined Interface");
    }
    //Defualt can be used to defined the Method in Interface
            
}

interface df
{
//This is marker interface
//No methods are defined    
} 

class sd implements df
{
    public void show()
    {
        System.out.println("Granted");
    }
}