// In Java everything is pass by value
package javaapplication2;

/*To pass object
1]create object
2]pass the object to method
3]use that obj to call method of class
*/ 

public class B2_ObjectPassing {


    public static void main(String[] args) 
    {
        Paper obj=new Paper(); //
        obj.set("Chin2");
        String t=obj.get();
        System.out.println(t);
        printer obj2=new printer();
        obj2.Print(obj);      //Now we have one Object and Two Refrences which means they will have the same Hash Code
        System.out.println(obj.get());
    }
    
}

class Paper 
{
    String t;
    public void set(String s)
    {
        t=s;
    }
    
    public String get()
    {
        return t;
    } 
}

class printer
{
    public void Print (Paper p)
    {
        p.set("Abhijit");
    }
}