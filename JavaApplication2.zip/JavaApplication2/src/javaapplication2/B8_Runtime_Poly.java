package javaapplication2;

//Refrence of class dosent matter as it will c

public class B8_Runtime_Poly {

    public static void main(String[] args) {
        Run o=new Run();
        o.R();                  //Object of class Matters
       
        Run obj=new walk();  //**********Here we are taking refrence of parent class because using it we can create object of any sub class
                              //Best use of memory and helps in garbage collectons
                              //This is dyanmic Polymorphisim
                              
        //walk obj1=new Run(); //*Using ref of child class we can create object of 2nd Class only
        obj.R();
        
        //obj.P();           //But with object with refrence to parent class cant call the other methods of child class(Not Overriden method)
        
        walk obj1=new walk();
        obj1.P();            //Object with refrence to same class as method present.
        
        
        

    }
    
}
class Run{
   
    public void R(){
        System.out.println("Hey");
}
}
class walk extends Run{
    public void P(){                                  
        System.out.println("Run");
    }
    
    public void R(){
        System.out.println("Dynamic Polymorphisim");
    }
}
