
package javaapplication2;

import java.util.*;
public class F3_Array {


    public static void main(String[] args) {
        
        //Arrays with numbers
        int [] x={1,2,3,4,5,6,10,9,8,7};                          //They are of fixed sized they cannot be increased now
        System.out.println(x[9]);
        x[9]=12;
        Arrays.sort(x);
        System.out.println(Arrays.toString(x));
        System.out.println("");
        
        //Arrays with String
        String[] s={"a","b","q","d"};
        Arrays.sort(s);
        
        System.out.println(Arrays.toString(s));
        System.out.println("");
                
        //List
        List<String> list = new ArrayList<String>();
        list.add("1");
        list.add("2");
        System.out.println(list);
        System.out.println("");
        
        //ArrayList
        ArrayList<String> Al = new ArrayList<String>();
        Al.add("Abhijit");
        Al.add("Suresh");
        Al.add("Kolekar");
        System.out.println(Al);   //prints [Abhijit, Suresh, Kolekar]
        System.out.println("");
        
        
        //Arrray to list =====>>>> asList
        Integer [] x1=new Integer[] {1,2,3,4,5};
        List<Integer> ldd= Arrays.asList(x1);
        System.out.println(ldd);        //ptints [1, 2, 3, 4, 5]
        System.out.println("");
        
        //Array to list ====>>>>list.of
        Integer [] i={1,34,53,3,2};
        List<Integer> l3=List.of(i);
        System.out.println(l3);        //prints  [1, 34, 53, 3, 2]
        System.out.println(l3.get(1)); //prints  34
        System.out.println("");
        
        //
        String[] objects = {"Apple", "Ball", "Cat"};
        List<String> objectList = List.of(objects);
        System.out.println(objectList);
      

        
        //String to Arrays  ====>>>toCharArray 
        String a="Abhijit";
        String b="Bhaijit";
        char aa[] = a.toLowerCase().toCharArray();
        char bb[] = b.toLowerCase().toCharArray();
 
        System.out.println(aa[0]);
        System.out.println(aa);
        if(a.length() != b.length()){
            System.out.println("NOT Equal");
        }else{
            Arrays.sort(aa);
            Arrays.sort(bb);
            System.out.println(aa);
            System.out.println(bb);
            System.out.println(java.util.Arrays.equals(aa, bb));
        }
        
    }
    
}
