/*                              Object Cloning
    Copying  object
    There are three Types
    1]-Shallow Copy
    2]-Deep Copy
    3]-Clone Copy
 */
package javaapplication2;


public class Object_Cloning {

    
    public static void main(String[] args) throws Exception
    {
        oc obj=new oc();
        obj.i=5;
        obj.j=10;
//   1] Shallow Copy=>>
        oc obj1=obj;  
//     This will create two but it creates Two Refrence

//   2] Deep Copy
        oc obj2=new oc();
        obj2.i=obj.i;
        obj2.j=obj.j;
//    This will create two object but it takes too much 

//    3]Clone
        //.obj3= obj.clone();
    }
    
}

class oc
{
    int i,j;
    
}