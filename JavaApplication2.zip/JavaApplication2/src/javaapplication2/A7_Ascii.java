
package javaapplication2;
//In Printf Use %d for Interger and %c for char
//Range OF A7_Ascii value is 0 to 127
public class A7_Ascii 
{
         
    public static void main(String[] args) 
    {
         int i=0;
         while(i<128)
            {
                System.out.printf("%d : %c ",i,i);
                System.out.println("");
                i++;
            }
        
    }

   
}
