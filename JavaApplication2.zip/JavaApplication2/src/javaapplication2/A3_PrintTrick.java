//Wihtout using semicolon print print statment
package javaapplication2;

public class A3_PrintTrick {

    public static void main(String[] args) 
    {
       if(System.out.printf("Hello World ")==null)
       {
           
       }
    }
    
}
