/*
                                                        Exception
    1]Error and Exception are two different things
    Exception can be handled by user
    Error cant be handeld aby user
    
    Types of Exception
    1]Checked-if can handled by User-IOException-SQLexception
    2]Unchecked-can't Handel by User-RuntimeException

    Throwable   -Exception -
                -Erorr
 */

package javaapplication2;
import java.lang.Exception;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
public class Excepti1 
{

    public static void main(String[] args) throws Exception//This will suppress error 
    {
        int i,j=0,k=0;   //Normal Statement 
        i=9;
        BufferedReader inp=new BufferedReader(new InputStreamReader(System.in));
        
        j=Integer.parseInt(inp.readLine());
        int a[]=new int [4];
        try
        {   
            j=Integer.parseInt(inp.readLine());
            k=i/j;           //Critical Statement
            for(int h=0;h<=4;h++)
            {
                a[h]=h+1;
            }
            for(int c:a)
            {
                System.out.println("a");
            }
        }
        catch(IOException ef)
        {
            System.out.println("");   
        }
        catch(ArithmeticException e)
        {
            System.out.println("Cannot Divide bye Zero");
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Array Index is Out off range");
        }
        catch(Exception e)                       //It handels all the Error
        {
            System.out.println(e);         
        }
        finally                          //No Matter What it will run
        {
            System.out.println("BYe");
        }   
        System.out.println(k);
        
    
    }
    
}
