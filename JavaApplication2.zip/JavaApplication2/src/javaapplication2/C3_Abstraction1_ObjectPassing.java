
package javaapplication2;


public class C3_Abstraction1_ObjectPassing 
{

    public static void main(String[] args) 
    {   
        Moto mo=new Moto();
        Iphone op=new Iphone();
        show(op);           //this will
        show(mo);
        
 
        
    }
    public static void show(phone obj)       // Depending upon object pass it will run the show
    {                                       //if Mo had passed it would have showed moto
        obj.show();
    }
 /*   public static void show(Iphone op)
    {
        op.show();
    }
    public static void show(Moto mo)         //NO need if using abstract
    {
        mo.show();
    }
   */ 
}


abstract class phone
{
    public abstract void show();
}

class Iphone extends phone
{
    public void show()
    {
        System.out.println("I Am Iphone");
    }
}
class Moto extends phone
{
    public void show()
    {
        System.out.println("I Am Moto");
    }
}