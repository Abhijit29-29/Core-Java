package javaapplication2;

// https://www.geeksforgeeks.org/private-constructors-and-singleton-classes-in-java/
public class B1_Private_Constructor {
    private B1_Private_Constructor(){
        System.out.println("This private Construcot needs to create the object og this class within same class ");
        
}
    public static void main(String[] args) {
        B1_Private_Constructor obj=new B1_Private_Constructor();
    }
            
    
}
