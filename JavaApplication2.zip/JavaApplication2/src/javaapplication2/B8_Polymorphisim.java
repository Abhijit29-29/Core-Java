 /*      
https://www.geeksforgeeks.org/polymorphism-in-java/
https://www.upgrad.com/blog/types-of-polymorphism-in-java/



        Polymorphisim
        poly=Many
        Moriphisim-Behaviour
        There are two types of PolyMorphisim 
        1:-Compile Time Polymorphisim/Static Polymorphism/Early Binding
        2:-Runtime Polymorphisim/Dynamic Polymorphism/Late Binding

        1.Compile-time polymorphism: It is also known as static polymorphism.It is process where call to functions of same name is resolved at compile time as compiler 
        already know which method to call depending upon no. of parameters and type of parameters.This type of polymorphism is achieved by function overloading or operator overloading.
        But Java doesn’t support the Operator Overloading.

        2.It is also known as Dynamic Method Dispatch. It is a process in which a function call to the overridden method is resolved at Runtime. 
        This type of polymorphism is achieved by Method Overriding.


        1]Method Overloading--When you have two or more method with same name but different Parameter in class
        2]Method Overriding--When you have two methods of same name with same parameter the 2nd method[Child class method] will override the 1st[Parent Child]

 */
package javaapplication2;

public class B8_Polymorphisim {

  
    public static void main(String[] args) 
    {   
        poly obj1=new poly();
        obj1.v1();
        mirphisim obj=new mirphisim();
        obj.v1();
        obj.v1(5);
        obj.v1(5f);
    }
    
}
//Do refer Runtime Polymorphism*************
class poly
{
    public void v1()
    {
        System.out.println("Hello");
    }
    public void v1(int i)          //This is Method Overloading
    {
        System.out.println("Hi");
    }
    public void v1(float f)           //Overloading
    {
        System.out.println("Hey");
    }
    
    
}

class mirphisim extends poly
{
    public void v1()                //This method Overriding,Late Binding,Dynamic Binding,Run Time Binding
    {
        System.out.println("Overriding");
    }
   
}