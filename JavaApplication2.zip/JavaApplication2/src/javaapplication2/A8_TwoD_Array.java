
package javaapplication2;
//When we have similar type of elements we make array which include all this elements
//When we have similar type of arrays of same size then we make array which include all this ---it is known as 2D array


public class A8_TwoD_Array {

  
    public static void main(String[] args) {
        
     //int a[][]=new int [rows (------)][colums (|||||||) ];   
     int a[][]=new int[3][2];
     int a1[][]={{1,2,3,4},
                 {2,3,4,5},
                 {2,3,4,6}
                  
    };
     //Simple For Loop
/*        for(int i=0;i<4;i++){
            
            for(int j=0;j<4;j++){
                System.out.print(a1[i][j]+" ");
                
            };
            System.out.println("");
        };
*/
    //Enhanced for loop
    for(int p[]:a1){
        for(int p1:p){
            System.out.print(p1+" ");  
        };
        System.out.println("");
        
        
    }
        System.out.println("Jagged Array");
        
    //Jagged Array
    int a2[][]={{1,2,3,4},
                {2,3},
                {2,3,4}
                  
    };
    for(int p[]:a2){
        for(int p1:p){
            System.out.print(p1+" ");  
        };
        System.out.println("");
        
        
    }
    
    //Defining Jagged Array
    int k[][]=new int[3][];      //As here we know the 3 rows are fixed but coloums are not fixed
    k[0]=new int[4];
    k[1]=new int[2];        //Defining Size of Coloums of Array
    k[2]=new int[3];
    
        
      } 
    
}
