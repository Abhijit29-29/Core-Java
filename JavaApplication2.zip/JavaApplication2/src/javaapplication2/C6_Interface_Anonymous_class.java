/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author amark
 */
public class C6_Interface_Anonymous_class
{

  
    public static void main(String[] args) 
    {
      // Anonymous Class
        IB ob=new IB()
        {
            public void d1()
            {
                System.out.println("Hey I am From Anonymous class");
            }
        };
        ob.d1();
        
        
        //Functional Interface
        ffd oo=() ->System.out.println("Heehehehe");
        oo.show();
        
        
    }
    
}
interface IB
{
    public abstract  void d1();  //Every Method in Interface is Abstract
    
}
interface ffd
{
    public void show();
}