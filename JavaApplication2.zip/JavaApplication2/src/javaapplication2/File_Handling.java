/*

 */
package javaapplication2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.Exception;

public class File_Handling {
    

    
    public static void main(String[] args) 
    {
//        To write in File use method write()
        try
        {
//          Writing
        File f=new File("Demo.txt");    
        FileOutputStream fos = new FileOutputStream("Demo.txt");    //This will ask u for File Name
        DataOutputStream dos =new DataOutputStream(fos);            //This will ask u for FileOutputStream object
        dos.writeUTF("Abhijit Kolekar Mumbai");                    //To Write in method use Write() Method UTF-Type of Format Notepad Follows UTF =>>belongs to class DataInputStream
//        Reading
        FileInputStream fis=new FileInputStream("Demo.txt");
        DataInputStream dis=new DataInputStream(fis);
        String rtv=dis.readUTF(dis);
            System.out.println(rtv);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
       
    }
    
}
