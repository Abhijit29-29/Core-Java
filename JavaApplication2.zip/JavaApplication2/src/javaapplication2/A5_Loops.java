
package javaapplication2;


public class A5_Loops {

    public static void main(String[] args) 
    {
       int i=5;
       while(i<10)          // while loop check condition before iteration of the loop.
       {
           System.out.printf("Hello While %d",i);
           System.out.println("");
           i++;
       }
      
       do                   //the do-while loop verifies the condition after the execution of the statements inside the loop.
       {
           System.out.printf("Hello DO %d",i);
           System.out.println("");
           i++;
       }while(i<10);          //The condition is false but still is runs 1st Case 
       
       for(int j=1;j<=5;j++)
       {
           System.out.printf("Hello For %d",j);
           System.out.println("");
       }
    }
}