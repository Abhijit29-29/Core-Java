
package javaapplication2;
//            https://www.javatpoint.com/StringBuilder-class ******************READ****************


public class F1_StringBuilder {

    public static void main(String[] args) {
        //StringBuilder Function
        String A="Abhijit";
        StringBuilder s=new StringBuilder(A);
        System.out.println(s.reverse());
        System.out.println();
        
        if(A.equals(s.reverse().toString())){
            System.out.print("Yes");
        }
        else System.out.println("No");
    }
    
}
