
package javaapplication2;


public class A1_Ifelse {

    
    public static void main(String[] args) 
    {
      
        int i=5;
        int j=6;
        System.out.println(j);
        if(i==1)
        {
            j=4;
        }
        else if (i==5)
        {
            j=8;
                
        }
        else 
        {
            j=10;
            
        }
        System.out.println(j);
                
                
        
                
    }  
    
}
    
    

