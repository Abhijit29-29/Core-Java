/*
    Final can be used with variables,method and class
    Once the final Keyword is used---
    1-Class cannot be extended
    2-Method cannot be Overriden
    3-Variable value cant be Changed
 */
package javaapplication2;

public class C1_Final 
{

    
    public static void main(String[] args) 
    {
        final int i=10;
//        i++;          cannot be incremented
        System.out.println(i+" Final Variable");
        
    }
    
    
}

final class f1
{
    public void fk()
    {
        System.out.println("Final Class");
    }
    
}

//class f2 extends f1         Cannot extend as f1 is final class

class f2
{
    public final void fd()
    {
        System.out.println("Final Method");
    }
}
class f3ds extends f2
{
//    public void fd()        Cannot Override as fd is Final Method
    {
        
    }
    
}
