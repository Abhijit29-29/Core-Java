//https://www.javatpoint.com/super-keyword
package javaapplication2;


public class B9_Super 
{
    public static void main(String[] args) 
    {
        s2 obj=new s2();      //This will call two Default Constructor\
        System.out.println("");
        s2 obj1=new s2(5);      // This will call defualt of s1 and s2 para
        System.out.println("");
        obj.ab();
               
    }
    
}


class s1
{
    public s1()        //Super
    {
        System.out.println("s1 Constructor");
    }
    public s1(int i)
    {
        System.out.println("s1 Constructor with para");
    }
    public void ab()
    {
        System.out.println("s1");
    }
}

class s2 extends s1
{
    public s2()
    {
        super();            //This helps u to call the defualt Constructor of A
        System.out.println("s2 Constructor");
    }
    public s2(int i)
    {   //super();      //This helps u to call the defualt Constructor of A No need to write it,it is there bydefualt
                            
        super(i);     //Only one super in method now this will call the para construtor of A
        System.out.println("s2 Constructor with para");
    }
    public void ab()              //Over-riding
    {
        super.ab();                //We can still run that method using Super
        System.out.println("s2"); 
    }
}