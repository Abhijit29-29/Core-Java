/*
                                                    Interface-----[Implement]
    Another way to achieve abstraction in Java, is with interfaces.

    An interface is a completely "abstract class" that is used to group related methods with empty bodies:

    In Interface u can only Declared the Method*****

    No object creation like 
    
    Helps in Multiple Inheritance
    It is used to achieve abstraction and multiple inheritance in Java.
 */

//      Types Of Interfaces
/*
        1]Marker Interface--->Without any Methods
        2]Single abstract Method ---> Functional Interface
        3]Normal
*/
package javaapplication2;


public class C4_Interface {

   
    public static void main(String[] args) 
    {
        B obj=new B();
        obj.show();
        obj.display();
        obj.d1();
        System.out.println("");
        
        IA obj1=new B();  //Here the Refrence of IA is taken but memoey of B
        
        obj1.show();
        System.out.println("");
//      obj1.display();    It will give the error as the it the refrence of A
      
//     
    




    }
    
}

interface  IA
{
     void show();   //Only Declared 
                           //Every Method in Interface is Public  Abstract  #No need to write
}
interface IB
{
    public abstract void d1();
   
    
}

class B implements IA,IB
{
    public void show()
    {
        System.out.println("Interface Defined");
        
    }
    public void display()
    {
        System.out.println("Done");
    }
    
   public void d1()
   {
       System.out.println("Hey I am IB");
   }
}

