/*      Inheritance
        In Java every class extends bydefualt Object Class
        if you chan't change the previous class then make another class and extend it with Previous class
        IF you inherit the class all the function of one will have in 2nd Class
        [Parent,Super,Base]   [Child,Sub,Derived]
        Types of Inheritamce
        1]-Single Level Inheritance  A--->B
        2]-Multi Level Inheritance A--->B-->C
        3]-Multiple Inheritance A--->,B,C     Not Supported in Java Why?
        If parent class has show() method and child class too has same method if both the class are extended by Grandchild class 
        then which method to execute that will create error.Hence,Mutltiple inheritance is not Supported.

 */
package javaapplication2;


public class B7_Inheritance {

    
    public static void main(String[] args) 
    {
       Child obj=new Child();                   //Constructor Of Parent and Child will be executed
//       obj.par();                               //BY using Child class obj we can call the parent class Function
//       obj.chi();  
//       obj.show();
//       Grandchild obj1=new Grandchild();         //All three Constructors are called.
//       obj1.Gra();
        
    }
    
}

class Parent      //[Parent,Super,Base]
{
    public Parent()
    {
        System.out.println("Parent class Constructor");
    }
    public void par()
    {
        System.out.println("Parent Class");
     
        
    }
    public void show(){
        System.out.println("SHOW");
    }
 
  
            
}

class Child extends Parent //[Child,Sub,Derived]      Single Level Inheritane
{
    public Child()
    {
        System.out.println("Child class Constructor");
    }
    public void chi()
    {
        System.out.println("Child Class");
     
    }
    public void show(){
        System.out.println("SHOW -I Am Overriding the SHOW method from Parent Class");
        System.out.println("");
    }
}

class Grandchild extends Child
{
    public Grandchild()
    {
        System.out.println("Grandchild class Constructor");
    }

    public void Gra()
    {
        System.out.println("Mutli Level Inheritance");
        System.out.println("");
                
    }
}