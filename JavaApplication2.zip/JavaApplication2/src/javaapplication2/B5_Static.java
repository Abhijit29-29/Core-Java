
package javaapplication2;
//import [][Package Name].[Class Name].[Method Or Object] 
import static java.lang.System.out;         //Now while using print statment we dont need to use System-which is a class name
import static javaapplication2.sta.pri;     //Now while calling the Static Method we dont need to used class name

public class B5_Static 
        /*
        Static Block
        It is block which executed 1st JVM before Main Method
        Use of Static-
        1)To assign the value to static Variables                
        */
{
    static    
    {
        System.out.println("Hello I am Static Block and I'll be Executed before anyother method or Class");
        System.out.println("");
        
    }
    
    public static void main(String[] args) 
    {   
        System.out.println("I Am Main Method");
        System.out.println("");
        out.println("Hello I am Print without the class name System ");
        
        sta.k=25;
        sta.pri();           //Calling Static Method by Class Name
        
        sta obj=new sta();
        obj.i=50;
        obj.show();
    }
    static
    {
     System.out.println("Hello I am Static 2 Block and I'll be Executed before anyother method or Class");   
    }
    
}

class sta
{
    int i;           //To assign Value to non static variable you need to create the obj of class
    static int k;    //To assign value to Static no need to create obj   
    public static void pri()
    {
        System.out.println("Hi I Static Method NO need to create the obj to call me U can use class name");
        System.out.println(k);
        System.out.println("");
    }
    public static void pri2()
    {
        System.out.println("Hi  I Pri2 Static Method NO need to create the obj and no need to used class name as u have imported as static ");
        
    }
    
    public void show()
    {
        System.out.println("No Static method, Pls create the obj to call me");
        System.out.println("Non Static Variables " +i );
        k++;
        System.out.println("Static Variable "+ k);
    }
}

//We can use static variable in non static method but we cant use nons static variable in static method
