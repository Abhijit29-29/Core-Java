/*                                 **********READ**********  https://www.javatpoint.com/StringBuffer-class **********READ**********

Java StringBuffer class is used to create mutable (modifiable) String objects. The StringBuffer class in Java is the 
same as String class except it is mutable i.e. it can be changed.

*/
package javaapplication2;

public class F2_StringBuffer {

    public static void main(String[] args) {
        StringBuffer sb=new StringBuffer("Hello ");  
        
        sb.append("Java");//now original string is changed  
        System.out.println(sb);//prints Hello Java  
        
        sb.insert(1,"Java");
        System.out.println(sb);   //prints HJavaello Java
        
        sb.replace(1,3,"PYTHON");  
        System.out.println(sb);    //HPYTHONvaello Java
        
        sb.delete(1,9);  
        System.out.println(sb);//prints Hlo  
        
        
        
        
    }
    
}
