
package javaapplication2;


public class B4_Count_Obj_Class {

    
    public static void main(String[] args) 
    {
       co obj=new co();
       obj=new co();         //here new object is created but the refrence is same 
       co obj2=new co();
       co obj3=new co();
       obj.show();
    }
    
}

class co
{
    static int i;
    public co()   //This is constructor 
    {
            i++;    //Every time the object is created it will bydefault run this constructor
    }
    public void show()
    {
        System.out.println(i);
    }
}