/*
 The public keyword is an access modifier, meaning that it is used to set the access level for classes, attributes, methods and constructors.

We divide modifiers into two groups:

Access Modifiers - controls the access level
Non-Access Modifiers - do not control access level, but provides other functionality
 */
package javaapplication2;
//Public Classes can be accessed outside package
//Defualt-Specific Package
//Private-Specific pa
//Protected-Subsiding Class

public class B3_Modifiers__Javap 
{

    public static void main(String[] args) 
    {
        // TODO code application logic here
    }
    
}

class jp
{
    public jp()
    {
        System.out.println("Hello");
    }
    
}
//Javac to compile the java file #Creates the Class file
// U Can get the java code from class file(Byte Code)
//But with the help of javap u can get Structure of code using javap command from class file
