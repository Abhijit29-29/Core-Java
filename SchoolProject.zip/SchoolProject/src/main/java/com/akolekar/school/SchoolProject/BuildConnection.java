package com.akolekar.school.SchoolProject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class BuildConnection {
	private Configuration Conf;
	private JDBCConnection Con;
	private SessionFactory sF;
	public BuildConnection(){
		Con = new JDBCConnection();
		Conf = Con.SetConfiguration();
		sF = Con.CreateSessionFactory(Conf, Con.BuildServiceRegistry(Conf));
	}
	public Session GetSession() {
		return Con.OpenSession(sF);
	}
	
}

