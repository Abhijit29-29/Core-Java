package com.akolekar.school.SchoolProject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int RollNo;
	private String House;
	@ManyToOne
	private ClassrommDetails StudentClass;
	
	@ManyToMany (mappedBy = "student1")
	private List<CourseDetails> Courses = new ArrayList<CourseDetails>();
	
	@OneToOne 
	private StudentDetails StudDetails;

	public void setRollNo(int rollNo) {
		RollNo = rollNo;
	}
	public String getHouse() {
		return House;
	}
	public StudentDetails getStudDetails() {
		return StudDetails;
	}
	public void setStudDetails(StudentDetails studDetails) {
		StudDetails = studDetails;
	}
	public int getRollNo() {
		return RollNo;
	}
	public void setHouse(String house) {
		House = house;
	}
	
	public ClassrommDetails getStudentClass() {
		return StudentClass;
	}
	public void setStudentClass(ClassrommDetails studentClass) {
		StudentClass = studentClass;
	}
	public List<CourseDetails> getCourses() {
		return Courses;
	}
	public void setCourses(List<CourseDetails> courses) {
		Courses = courses;
	}
	
	
	
}
