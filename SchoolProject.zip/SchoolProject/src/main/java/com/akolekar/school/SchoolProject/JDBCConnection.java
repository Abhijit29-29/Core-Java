package com.akolekar.school.SchoolProject;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class JDBCConnection {
	public Configuration SetConfiguration() {
		return new Configuration().configure().addAnnotatedClass(CourseDetails.class).addAnnotatedClass(ClassrommDetails.class).addAnnotatedClass(StudentDetails.class).addAnnotatedClass(Student.class).addAnnotatedClass(TeacherDetails.class).addAnnotatedClass(Courses.class);
	}
	public ServiceRegistry BuildServiceRegistry(Configuration Conf) {
		return new ServiceRegistryBuilder().applySettings(Conf.getProperties()).buildServiceRegistry();
	}
	public SessionFactory CreateSessionFactory(Configuration Conf ,ServiceRegistry reg) {
		return  Conf.buildSessionFactory(reg);
	}
	public Session OpenSession(SessionFactory Sf){
		return Sf.openSession();
		
	} 
}
