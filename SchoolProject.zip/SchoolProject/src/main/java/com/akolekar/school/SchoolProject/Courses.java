package com.akolekar.school.SchoolProject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Courses {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "course_id")
	private int CourseID;
	
	private String CourseName;
	@OneToOne (mappedBy = "Coursenaame")
	private TeacherDetails Professor;
	public int getCourseID() {
		return CourseID;
	}
	public void setCourseID(int courseID) {
		CourseID = courseID;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public TeacherDetails getProfessor() {
		return Professor;
	}
	public void setProfessor(TeacherDetails professor) {
		Professor = professor;
	}

}
