package com.akolekar.school.SchoolProject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class ClassrommDetails {
	@Id
	private int Standard;
	@OneToMany (mappedBy = "StudentClass")
	private List<Student> Students = new ArrayList<Student>();
	@OneToOne 
	private TeacherDetails ClassTeacher;	
	
	public int getStandard() {
		return Standard;
	}
	public void setStandard(int standard) {
		Standard = standard;
	}
	public List<Student> getStudents() {
		return Students;
	}
	public void setStudents(List<Student> students) {
		Students = students;
	}
	public TeacherDetails getClassTeacher() {
		return ClassTeacher;
	}
	public void setClassTeacher(TeacherDetails classTeacher) {
		ClassTeacher = classTeacher;
	}
	

}
