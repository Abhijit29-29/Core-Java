package com.akolekar.school.SchoolProject;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class StudentDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int StudentID;
	private double ContactNo;
	private String Address;
	
	@OneToOne (mappedBy = "StudDetails")
	private Student student;
	public int getStudentID() {
		return StudentID;
	}
	public double getContactNo() {
		return ContactNo;
	}
	public void setContactNo(double contactNo) {
		ContactNo = contactNo;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	

}
