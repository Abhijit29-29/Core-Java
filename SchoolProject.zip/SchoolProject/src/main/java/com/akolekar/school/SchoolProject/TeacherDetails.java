package com.akolekar.school.SchoolProject;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class TeacherDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long TeacherID;
	private String TecherName;
	
	@OneToOne
	private Courses Coursenaame;
	@OneToOne (mappedBy = "ClassTeacher")
	private ClassrommDetails classroom;
	
	public ClassrommDetails getClassroom() {
		return classroom;
	}
	public void setClassroom(ClassrommDetails classroom) {
		this.classroom = classroom;
	}
	public long getTeacherID() {
		return TeacherID;
	}

	public Courses getCoursenaame() {
		return Coursenaame;
	}
	public void setCoursenaame(Courses courseName) {
		Coursenaame = courseName;
	}
	public String getTecherName() {
		return TecherName;
	}
	public void setTecherName(String techerName) {
		TecherName = techerName;
	}

}
