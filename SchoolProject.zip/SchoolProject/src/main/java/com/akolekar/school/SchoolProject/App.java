package com.akolekar.school.SchoolProject;

import org.hibernate.Session;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {	
//    	Student student = new Student();
//    	student.setHouse("Blue");
//
//    	
//    	StudentDetails studentdetails = new StudentDetails();
//    	studentdetails.setAddress("Mumbai");
//    	studentdetails.setContactNo(986745);
//    	
//    	student.setStudDetails(studentdetails);
//    	studentdetails.setStudent(student);
//
//    	Courses course = new Courses();
//    	course.setCourseName("Maths");
//    	
//    	ClassrommDetails classdetail = new ClassrommDetails();
//    	classdetail.setStandard(4);
//    	classdetail.getStudents().add(student);
//    	student.setStudentClass(classdetail);
//    
//    		
//    	TeacherDetails teacher = new TeacherDetails();
//    	teacher.setCoursenaame(course);
//    	teacher.setTecherName("Subramaniyam");
//    	
//    	classdetail.setClassTeacher(teacher);
//    	teacher.setClassroom(classdetail);
//    	
//    	CourseDetails Coursedetails = new CourseDetails();
//    	Coursedetails.setCourse(course);
//    	Coursedetails.getStudent().add(student);
//    	Coursedetails.setEndDate("2023-12-12");
//    	Coursedetails.setStartDate("2022-12-12");
////    	student.getCourses().add(Coursedetails);
//    	session.beginTransaction();
//        session.save(studentdetails);
//        session.save(student);
//        session.save(course);
//        session.save(teacher);
//        session.save(classdetail);
//        session.save(Coursedetails);
    	
    	
    	TeacherDetails Teacher = new TeacherDetails();
    	Teacher.setTecherName("Sunenana");
    	
    	
    	
        System.out.println( "Hello World!" );
        try
        {
        	BuildConnection Conn = new BuildConnection();
            Session session = Conn.GetSession();
            session.beginTransaction();
            session.save(Teacher);
            session.getTransaction().commit();
        }
        catch(Exception e) {
        	System.out.println("Error");
			e.printStackTrace();
        }
  
    }
}
