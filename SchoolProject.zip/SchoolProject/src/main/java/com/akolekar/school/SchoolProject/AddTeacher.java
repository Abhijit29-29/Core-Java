package com.akolekar.school.SchoolProject;

import org.hibernate.Session;

public class AddTeacher {
	private String name;
	private Courses course;
	private ClassrommDetails classroom;
	public AddTeacher(Session session,String teacherName){
		this.name = teacherName;
		
	}
	public AddTeacher(Session session,String teacherName,Courses Course){
		this.course = Course;
		this.name = teacherName;
	}
	public AddTeacher(Session session,String teacherName, Courses Course, ClassrommDetails classroom){
		this.course = Course;
		this.classroom = classroom;
		this.name = teacherName;
	}
	private void SaveToDatabase(Session session) {
		TeacherDetails Teacher = new TeacherDetails();
		session.beginTransaction();
		
		
	}
	

}
