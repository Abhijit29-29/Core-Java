package com.akolekar.school.SchoolProject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;



@Entity
public class CourseDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "course_id")
	private int CourseID;
	
	public Courses getCourse() {
		return course;
	}
	public void setCourse(Courses course) {
		this.course = course;
	}
	@OneToOne
	@JoinColumn (name = "course_id", referencedColumnName = "course_id")
	private Courses course;
	
	@ManyToMany
	private List<Student> student1 = new ArrayList<Student>();
	
	private String StartDate;
	
	public String getStartDate() {
		return StartDate;
	}
	public void setStartDate(String startString) {
		StartDate = startString;
	}
	public String getEnddate() {
		return EndDate;
	}
	public void setEndDate(String endString) {
		EndDate = endString;
	}
	private String EndDate;
	public List<Student> getStudent() {
		return student1;
	}
	public void setStudent(List<Student> student) {
		student1 = student;
	}
	
}
